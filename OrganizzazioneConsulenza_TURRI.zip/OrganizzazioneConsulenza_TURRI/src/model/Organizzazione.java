package model;

public enum Organizzazione {
	INTERNO,
	ESTERNO;
}
