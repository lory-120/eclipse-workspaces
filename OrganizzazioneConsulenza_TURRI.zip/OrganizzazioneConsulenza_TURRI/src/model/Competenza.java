package model;

public enum Competenza {
	INFORMATICA,
	ELETTRONICA;
}
