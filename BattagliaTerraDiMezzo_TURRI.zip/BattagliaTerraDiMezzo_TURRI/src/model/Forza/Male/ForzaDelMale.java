package model.Forza.Male;

import model.Forza.Forza;

abstract public class ForzaDelMale extends Forza {

	public ForzaDelMale(String nome) {
		super(nome);
	}
	
}
