package model.Forza.Bene;

import model.Forza.Forza;

public abstract class ForzaDelBene extends Forza {

	public ForzaDelBene(String nome) {
		super(nome);
	}
	
}
