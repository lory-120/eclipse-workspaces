package model.Eroe;

public class EroeDelMale {

}
