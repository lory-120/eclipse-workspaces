package model.Paziente;

public class PazienteRosso extends Paziente {

	public PazienteRosso(String nome, String cognome, int eta) {
		super(nome, cognome, eta);
	}
	
	public PazienteRosso() {
		super();
	}
	
}
