package model.Paziente;

public class PazienteBianco extends Paziente {

	public PazienteBianco(String nome, String cognome, int eta) {
		super(nome, cognome, eta);
	}
	
	public PazienteBianco() {
		super();
	}
	
}
