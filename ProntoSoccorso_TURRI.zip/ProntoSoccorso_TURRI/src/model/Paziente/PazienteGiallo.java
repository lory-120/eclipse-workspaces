package model.Paziente;

public class PazienteGiallo extends Paziente {

	public PazienteGiallo(String nome, String cognome, int eta) {
		super(nome, cognome, eta);
	}
	
	public PazienteGiallo() {
		super();
	}
	
}
